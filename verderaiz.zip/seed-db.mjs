import { drizzle } from "drizzle-orm/mysql2";
import { categories, products } from "./drizzle/schema.js";

const db = drizzle(process.env.DATABASE_URL);

async function seed() {
  console.log("🌱 Iniciando seed do banco de dados...");

  try {
    // Inserir categorias
    console.log("📁 Criando categorias...");
    await db.insert(categories).values([
      {
        name: "Oversize",
        slug: "oversize",
        description: "Camisas e t-shirts oversized com design moderno e confortável",
        imageUrl: "/images/product-1.png",
      },
      {
        name: "Botão",
        slug: "botao",
        description: "Camisas premium com botões, perfeitas para ocasiões especiais",
        imageUrl: "/images/product-2.png",
      },
      {
        name: "Básica",
        slug: "basica",
        description: "Essenciais com propósito, peças versáteis para o dia a dia",
        imageUrl: "/images/product-1.png",
      },
    ]);

    console.log("✅ Categorias criadas com sucesso!");

    // Inserir produtos
    console.log("🛍️ Criando produtos...");
    await db.insert(products).values([
      {
        name: "Camiseta Oversize Árvore da Vida",
        slug: "camiseta-oversize-arvore-da-vida",
        description: "Camiseta oversized em algodão orgânico com estampa exclusiva da Árvore da Vida, simbolizando a conexão entre a Amazônia e o mundo.",
        price: 12900, // R$ 129,00
        categoryId: 1,
        imageUrl: "/images/product-1.png",
        images: JSON.stringify(["/images/product-1.png"]),
        fabric: "Algodão Orgânico 100%",
        fabricOrigin: "Cultivado na região amazônica",
        impactInfo: "Produção com 70% menos água e sem uso de pesticidas",
        isLimitedEdition: true,
        stock: 50,
        isActive: true,
      },
      {
        name: "Camisa VerdeRaiz Essencial",
        slug: "camisa-verderaiz-essencial",
        description: "Camisa verde musgo com logo bordado, perfeita para o dia a dia. Tecido respirável e sustentável.",
        price: 9900, // R$ 99,00
        categoryId: 3,
        imageUrl: "/images/product-2.png",
        images: JSON.stringify(["/images/product-2.png"]),
        fabric: "Algodão Orgânico e Fibras Recicladas",
        fabricOrigin: "Produzido localmente em Belém, PA",
        impactInfo: "Tingimento natural com plantas amazônicas",
        isLimitedEdition: false,
        stock: 100,
        isActive: true,
      },
      {
        name: "Camiseta Oversize Raízes",
        slug: "camiseta-oversize-raizes",
        description: "Design minimalista com estampa de raízes entrelaçadas, representando nossa conexão com a terra.",
        price: 11900, // R$ 119,00
        categoryId: 1,
        imageUrl: "/images/product-1.png",
        images: JSON.stringify(["/images/product-1.png"]),
        fabric: "Algodão Orgânico Premium",
        fabricOrigin: "Amazônia brasileira",
        impactInfo: "Cada compra planta uma árvore na Amazônia",
        isLimitedEdition: false,
        stock: 75,
        isActive: true,
      },
      {
        name: "Camisa Botão Floresta",
        slug: "camisa-botao-floresta",
        description: "Camisa premium com botões de madeira sustentável. Estampa inspirada na flora amazônica.",
        price: 15900, // R$ 159,00
        categoryId: 2,
        imageUrl: "/images/product-2.png",
        images: JSON.stringify(["/images/product-2.png"]),
        fabric: "Linho Orgânico",
        fabricOrigin: "Tecido importado com certificação sustentável",
        impactInfo: "Botões de madeira de reflorestamento",
        isLimitedEdition: true,
        stock: 30,
        isActive: true,
      },
      {
        name: "Camiseta Básica VerdeRaiz",
        slug: "camiseta-basica-verderaiz",
        description: "Camiseta básica em bege natural, perfeita para qualquer ocasião. Conforto e sustentabilidade.",
        price: 7900, // R$ 79,00
        categoryId: 3,
        imageUrl: "/images/product-1.png",
        images: JSON.stringify(["/images/product-1.png"]),
        fabric: "Algodão Orgânico",
        fabricOrigin: "Produção local",
        impactInfo: "Processo de tingimento natural sem químicos",
        isLimitedEdition: false,
        stock: 150,
        isActive: true,
      },
      {
        name: "Camiseta Oversize COP30",
        slug: "camiseta-oversize-cop30",
        description: "Edição especial COP30 com arte exclusiva. Parte da renda destinada a projetos de preservação.",
        price: 13900, // R$ 139,00
        categoryId: 1,
        imageUrl: "/images/product-1.png",
        images: JSON.stringify(["/images/product-1.png"]),
        fabric: "Algodão Orgânico e PET Reciclado",
        fabricOrigin: "Amazônia",
        impactInfo: "10% da renda para projetos ambientais",
        isLimitedEdition: true,
        stock: 100,
        isActive: true,
      },
    ]);

    console.log("✅ Produtos criados com sucesso!");
    console.log("🎉 Seed concluído!");
  } catch (error) {
    console.error("❌ Erro ao fazer seed:", error);
    process.exit(1);
  }

  process.exit(0);
}

seed();
