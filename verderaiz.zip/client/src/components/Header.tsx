import { Link } from "wouter";
import { ShoppingCart, Menu, X, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, isAuthenticated } = useAuth();
  const { data: cartItems } = trpc.cart.getItems.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const cartCount = cartItems?.reduce((sum, item) => sum + item.quantity, 0) || 0;

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        {/* Logo */}
        <Link href="/">
          <a className="flex items-center space-x-2">
            <img 
              src="/images/logo.jpeg" 
              alt="VerdeRaiz" 
              className="h-10 w-auto object-contain"
            />
          </a>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <Link href="/colecao">
            <a className="text-sm font-medium transition-colors hover:text-primary">
              Coleção
            </a>
          </Link>
          <Link href="/sobre">
            <a className="text-sm font-medium transition-colors hover:text-primary">
              Sobre
            </a>
          </Link>
          <Link href="/sustentabilidade">
            <a className="text-sm font-medium transition-colors hover:text-primary">
              Sustentabilidade
            </a>
          </Link>
          <Link href="/collabs">
            <a className="text-sm font-medium transition-colors hover:text-primary">
              Collabs
            </a>
          </Link>
          <Link href="/contato">
            <a className="text-sm font-medium transition-colors hover:text-primary">
              Contato
            </a>
          </Link>
        </nav>

        {/* Right Actions */}
        <div className="flex items-center space-x-4">
          {/* User Account */}
          {isAuthenticated ? (
            <Link href="/conta">
              <a className="hidden md:flex items-center space-x-2 text-sm font-medium transition-colors hover:text-primary">
                <User className="h-5 w-5" />
                <span>{user?.name || "Conta"}</span>
              </a>
            </Link>
          ) : (
            <a 
              href={getLoginUrl()} 
              className="hidden md:flex items-center space-x-2 text-sm font-medium transition-colors hover:text-primary"
            >
              <User className="h-5 w-5" />
              <span>Entrar</span>
            </a>
          )}

          {/* Shopping Cart */}
          <Link href="/carrinho">
            <a className="relative">
              <Button variant="ghost" size="icon">
                <ShoppingCart className="h-5 w-5" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </Button>
            </a>
          </Link>

          {/* Mobile Menu Toggle */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t bg-background">
          <nav className="container py-4 flex flex-col space-y-4">
            <Link href="/colecao">
              <a 
                className="text-sm font-medium transition-colors hover:text-primary"
                onClick={() => setMobileMenuOpen(false)}
              >
                Coleção
              </a>
            </Link>
            <Link href="/sobre">
              <a 
                className="text-sm font-medium transition-colors hover:text-primary"
                onClick={() => setMobileMenuOpen(false)}
              >
                Sobre
              </a>
            </Link>
            <Link href="/sustentabilidade">
              <a 
                className="text-sm font-medium transition-colors hover:text-primary"
                onClick={() => setMobileMenuOpen(false)}
              >
                Sustentabilidade
              </a>
            </Link>
            <Link href="/collabs">
              <a 
                className="text-sm font-medium transition-colors hover:text-primary"
                onClick={() => setMobileMenuOpen(false)}
              >
                Collabs
              </a>
            </Link>
            <Link href="/contato">
              <a 
                className="text-sm font-medium transition-colors hover:text-primary"
                onClick={() => setMobileMenuOpen(false)}
              >
                Contato
              </a>
            </Link>
            
            {isAuthenticated ? (
              <Link href="/conta">
                <a 
                  className="text-sm font-medium transition-colors hover:text-primary flex items-center space-x-2"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <User className="h-5 w-5" />
                  <span>{user?.name || "Minha Conta"}</span>
                </a>
              </Link>
            ) : (
              <a 
                href={getLoginUrl()} 
                className="text-sm font-medium transition-colors hover:text-primary flex items-center space-x-2"
              >
                <User className="h-5 w-5" />
                <span>Entrar</span>
              </a>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
