import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import Header from "@/components/Header";
import { Leaf, Heart, Users, Globe } from "lucide-react";

export default function Sobre() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* Hero Section */}
      <section className="relative py-20 bg-accent">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Nascemos da Amazônia
            </h1>
            <p className="text-xl md:text-2xl opacity-90 leading-relaxed">
              Crescemos com propósito. Vestimos o planeta.
            </p>
          </div>
        </div>
      </section>

      {/* Manifesto */}
      <section className="py-20">
        <div className="container max-w-4xl">
          <div className="prose prose-lg mx-auto">
            <p className="text-xl leading-relaxed text-muted-foreground mb-6">
              <strong className="text-foreground">VerdeRaiz</strong> é mais do que uma marca de moda. Somos um movimento que nasce 
              do coração da Amazônia, carregando em cada peça a essência da floresta, 
              a força das nossas raízes e o compromisso com o futuro do planeta.
            </p>
            
            <p className="text-xl leading-relaxed text-muted-foreground mb-6">
              Acreditamos que <strong className="text-foreground">vestir é um ato político</strong>. Cada escolha que fazemos 
              impacta o mundo ao nosso redor. Por isso, criamos roupas que respeitam 
              a natureza, valorizam o trabalho local e celebram a identidade nortista.
            </p>

            <p className="text-xl leading-relaxed text-muted-foreground">
              Nossa missão é simples: <strong className="text-foreground">vestir a Amazônia é vestir o futuro</strong>. 
              Queremos que cada pessoa que usa VerdeRaiz sinta-se parte dessa história, 
              dessa luta, dessa transformação.
            </p>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-muted/30">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Nossos Pilares
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Os valores que guiam cada decisão, cada criação, cada passo da VerdeRaiz
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="text-center p-8 hover:shadow-lg transition-shadow">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
                <Leaf className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Sustentabilidade</h3>
              <p className="text-muted-foreground">
                Tecidos ecológicos e processos que respeitam a natureza em cada etapa.
              </p>
            </Card>

            <Card className="text-center p-8 hover:shadow-lg transition-shadow">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
                <Users className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Comunidade</h3>
              <p className="text-muted-foreground">
                Valorizamos parcerias locais e o trabalho artesanal da Amazônia.
              </p>
            </Card>

            <Card className="text-center p-8 hover:shadow-lg transition-shadow">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
                <Heart className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Autenticidade</h3>
              <p className="text-muted-foreground">
                Cada peça conta uma história real, com identidade e propósito.
              </p>
            </Card>

            <Card className="text-center p-8 hover:shadow-lg transition-shadow">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
                <Globe className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Impacto Global</h3>
              <p className="text-muted-foreground">
                Da Amazônia para o mundo, levando consciência e transformação.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Story */}
      <section className="py-20">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold mb-6">Nossa História</h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  A VerdeRaiz nasceu em 2024, no coração da Amazônia, com o propósito 
                  de criar uma ponte entre a riqueza cultural do Norte brasileiro e o 
                  mundo da moda sustentável.
                </p>
                <p>
                  Inspirados pela força da natureza e pela autenticidade da nossa gente, 
                  decidimos criar roupas que não apenas vestem, mas que contam histórias, 
                  que carregam valores e que fazem a diferença.
                </p>
                <p>
                  Cada coleção é pensada para celebrar a Amazônia, suas cores, suas 
                  texturas, sua diversidade. E mais importante: cada peça é produzida 
                  de forma consciente, respeitando o meio ambiente e as comunidades locais.
                </p>
                <p>
                  Estamos comprometidos com a <strong>COP30</strong>, o maior evento 
                  climático do mundo que acontecerá em Belém, e queremos ser parte 
                  ativa dessa transformação global.
                </p>
              </div>
            </div>

            <div className="relative">
              <div className="aspect-square rounded-lg overflow-hidden bg-muted">
                <img
                  src="/images/product-1.png"
                  alt="VerdeRaiz - Nossa História"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-accent">
        <div className="container text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Faça Parte Dessa História
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
            Vista VerdeRaiz e seja parte do movimento pela Amazônia e pelo futuro do planeta.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/colecao">
              <a className="inline-block">
                <button className="px-8 py-4 bg-primary text-primary-foreground rounded-lg font-semibold hover:opacity-90 transition-opacity">
                  Conhecer a Coleção
                </button>
              </a>
            </Link>
            <Link href="/sustentabilidade">
              <a className="inline-block">
                <button className="px-8 py-4 border-2 border-primary text-primary rounded-lg font-semibold hover:bg-primary hover:text-primary-foreground transition-colors">
                  Nosso Compromisso
                </button>
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t bg-muted/20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <img 
                src="/images/logo-new.png" 
                alt="VerdeRaiz" 
                className="h-12 w-auto object-contain mb-4"
              />
              <p className="text-sm text-muted-foreground">
                Vestir a Amazônia é vestir o Futuro
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Navegação</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/colecao"><a className="text-muted-foreground hover:text-foreground transition-colors">Coleção</a></Link></li>
                <li><Link href="/sobre"><a className="text-muted-foreground hover:text-foreground transition-colors">Sobre</a></Link></li>
                <li><Link href="/sustentabilidade"><a className="text-muted-foreground hover:text-foreground transition-colors">Sustentabilidade</a></Link></li>
                <li><Link href="/collabs"><a className="text-muted-foreground hover:text-foreground transition-colors">Collabs</a></Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Suporte</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/contato"><a className="text-muted-foreground hover:text-foreground transition-colors">Contato</a></Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Redes Sociais</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="https://www.instagram.com/verderaizpa/" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground transition-colors">Instagram</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-foreground transition-colors">WhatsApp</a></li>
              </ul>
            </div>
          </div>
          
          <div className="mt-12 pt-8 border-t text-center text-sm text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} VerdeRaiz. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
