import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";
import { Users, Award, Handshake, Mail } from "lucide-react";

export default function Collabs() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* Hero Section */}
      <section className="relative py-20 bg-primary text-primary-foreground">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <Users className="h-16 w-16 mx-auto mb-6" />
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Colaborações
            </h1>
            <p className="text-xl md:text-2xl opacity-90 leading-relaxed">
              Unindo forças para amplificar o impacto positivo da moda sustentável
            </p>
          </div>
        </div>
      </section>

      {/* Intro */}
      <section className="py-20">
        <div className="container max-w-4xl text-center">
          <p className="text-xl leading-relaxed text-muted-foreground">
            Na VerdeRaiz, acreditamos que <strong className="text-foreground">juntos somos mais fortes</strong>. 
            Por isso, buscamos parcerias com artistas, influenciadores, marcas e organizações 
            que compartilham nossos valores de sustentabilidade, autenticidade e compromisso 
            com a Amazônia.
          </p>
        </div>
      </section>

      {/* Featured Collab */}
      <section className="py-20 bg-muted/30">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <Badge className="absolute top-4 left-4 z-10 bg-secondary">
                Collab Destaque
              </Badge>
              <div className="aspect-square rounded-lg overflow-hidden bg-muted">
                <img
                  src="/images/product-2.png"
                  alt="Collab Murilo Mitre"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            <div>
              <h2 className="text-4xl font-bold mb-4">
                VerdeRaiz x Murilo Mitre
              </h2>
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                Nossa primeira colaboração oficial une a essência da VerdeRaiz com 
                a visão artística de Murilo Mitre, criando peças únicas que celebram 
                a cultura amazônica e a moda consciente.
              </p>
              <p className="text-muted-foreground mb-8 leading-relaxed">
                Esta coleção limitada apresenta estampas exclusivas inspiradas na 
                fauna e flora da região, com 100% dos materiais sustentáveis e 
                parte da renda destinada a projetos de preservação ambiental.
              </p>
              <Link href="/colecao?categoria=collabs">
                <Button size="lg">
                  Ver Coleção Collab
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Selo VerdeRaiz */}
      <section className="py-20">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-6 py-3 rounded-full mb-6">
                <Award className="h-6 w-6" />
                <span className="font-bold text-lg">Selo VerdeRaiz</span>
              </div>
              <h2 className="text-4xl font-bold mb-4">
                Certificado de Autenticidade Sustentável
              </h2>
              <p className="text-lg text-muted-foreground">
                Cada peça VerdeRaiz possui um selo único que garante sua origem, 
                processo de produção e compromisso ambiental.
              </p>
            </div>

            <Card className="p-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-2xl font-bold mb-4">Como Funciona</h3>
                  <div className="space-y-4">
                    <div className="flex gap-3">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
                        1
                      </div>
                      <div>
                        <p className="text-muted-foreground">
                          Cada peça possui um <strong className="text-foreground">QR Code único</strong> na etiqueta
                        </p>
                      </div>
                    </div>

                    <div className="flex gap-3">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
                        2
                      </div>
                      <div>
                        <p className="text-muted-foreground">
                          Escaneie o código para acessar a <strong className="text-foreground">história completa</strong> do produto
                        </p>
                      </div>
                    </div>

                    <div className="flex gap-3">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
                        3
                      </div>
                      <div>
                        <p className="text-muted-foreground">
                          Veja informações sobre <strong className="text-foreground">materiais, origem e impacto ambiental</strong>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-muted/50 rounded-lg p-6 flex flex-col justify-center">
                  <Award className="h-24 w-24 mx-auto mb-4 text-primary" />
                  <p className="text-center font-semibold text-lg mb-2">
                    Selo de Autenticidade
                  </p>
                  <p className="text-center text-sm text-muted-foreground">
                    Transparência total do campo à sua casa
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Tipos de Colaboração */}
      <section className="py-20 bg-muted/30">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Tipos de Colaboração
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Estamos sempre abertos a novas parcerias que compartilhem nossos valores
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="p-8 text-center hover:shadow-lg transition-shadow">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
                <Users className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-2xl font-bold mb-3">Artistas & Designers</h3>
              <p className="text-muted-foreground mb-6">
                Coleções exclusivas que unem arte, moda e sustentabilidade em 
                peças únicas e limitadas.
              </p>
            </Card>

            <Card className="p-8 text-center hover:shadow-lg transition-shadow">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
                <Handshake className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-2xl font-bold mb-3">Marcas Sustentáveis</h3>
              <p className="text-muted-foreground mb-6">
                Parcerias estratégicas com empresas que compartilham nosso 
                compromisso com o meio ambiente.
              </p>
            </Card>

            <Card className="p-8 text-center hover:shadow-lg transition-shadow">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
                <Award className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-2xl font-bold mb-3">ONGs & Projetos Sociais</h3>
              <p className="text-muted-foreground mb-6">
                Apoio a iniciativas de preservação ambiental e desenvolvimento 
                de comunidades locais.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20">
        <div className="container">
          <Card className="bg-primary text-primary-foreground p-12 text-center">
            <Mail className="h-16 w-16 mx-auto mb-6" />
            <h2 className="text-4xl font-bold mb-4">
              Quer Colaborar Conosco?
            </h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
              Estamos sempre abertos a novas ideias e parcerias que possam 
              amplificar nosso impacto positivo no mundo.
            </p>
            <Link href="/contato">
              <a className="inline-block">
                <button className="px-8 py-4 bg-primary-foreground text-primary rounded-lg font-semibold hover:opacity-90 transition-opacity">
                  Entre em Contato
                </button>
              </a>
            </Link>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t bg-muted/20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <img 
                src="/images/logo-new.png" 
                alt="VerdeRaiz" 
                className="h-12 w-auto object-contain mb-4"
              />
              <p className="text-sm text-muted-foreground">
                Vestir a Amazônia é vestir o Futuro
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Navegação</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/colecao"><a className="text-muted-foreground hover:text-foreground transition-colors">Coleção</a></Link></li>
                <li><Link href="/sobre"><a className="text-muted-foreground hover:text-foreground transition-colors">Sobre</a></Link></li>
                <li><Link href="/sustentabilidade"><a className="text-muted-foreground hover:text-foreground transition-colors">Sustentabilidade</a></Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Suporte</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/contato"><a className="text-muted-foreground hover:text-foreground transition-colors">Contato</a></Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Redes Sociais</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="https://www.instagram.com/verderaizpa/" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground transition-colors">Instagram</a></li>
              </ul>
            </div>
          </div>
          
          <div className="mt-12 pt-8 border-t text-center text-sm text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} VerdeRaiz. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
