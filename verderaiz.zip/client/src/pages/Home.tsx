import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Leaf, Users, Heart } from "lucide-react";
import Header from "@/components/Header";
import { trpc } from "@/lib/trpc";

export default function Home() {
  const { data: categories, isLoading: categoriesLoading } = trpc.categories.getAll.useQuery();

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      {/* Hero Section */}
      <section className="relative h-[600px] md:h-[700px] flex items-center justify-center overflow-hidden">
        {/* Background Image */}
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: "url('/images/product-1.png')",
            filter: "brightness(0.7)",
          }}
        />
        
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-primary/30 to-primary/60" />
        
        {/* Content */}
        <div className="relative z-10 container text-center text-white">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            Vista o que é da terra
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-2xl mx-auto font-light">
            Da Amazônia para o mundo. Raiz que veste propósito.
          </p>
          <Link href="/colecao">
            <Button size="lg" variant="secondary" className="text-lg px-8 py-6">
              Conheça a Coleção
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-20 bg-muted/30">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Nossas Coleções
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Peças autênticas que conectam você com a essência da Amazônia
            </p>
          </div>

          {categoriesLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="overflow-hidden">
                  <div className="h-64 bg-muted animate-pulse" />
                  <CardContent className="p-6">
                    <div className="h-6 bg-muted animate-pulse mb-2" />
                    <div className="h-4 bg-muted animate-pulse w-2/3" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {categories && categories.length > 0 ? (
                categories.map((category) => (
                  <Link key={category.id} href={`/colecao?categoria=${category.slug}`}>
                    <Card className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group">
                      <div className="relative h-64 overflow-hidden">
                        <img
                          src={category.imageUrl || "/images/product-1.png"}
                          alt={category.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                      <CardContent className="p-6">
                        <h3 className="text-2xl font-bold mb-2">{category.name}</h3>
                        <p className="text-muted-foreground">{category.description}</p>
                      </CardContent>
                    </Card>
                  </Link>
                ))
              ) : (
                <div className="col-span-3 text-center py-12">
                  <p className="text-muted-foreground">Em breve, novas coleções!</p>
                </div>
              )}
            </div>
          )}
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Nossos Valores
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Mais do que moda, somos um movimento pela Amazônia
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center p-8 hover:shadow-lg transition-shadow">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
                <Leaf className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Sustentabilidade</h3>
              <p className="text-muted-foreground">
                Tecidos ecológicos e processos que respeitam a natureza. Cada peça é um compromisso com o planeta.
              </p>
            </Card>

            <Card className="text-center p-8 hover:shadow-lg transition-shadow">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
                <Users className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Comunidade</h3>
              <p className="text-muted-foreground">
                Valorizamos parcerias locais e o trabalho artesanal da região amazônica.
              </p>
            </Card>

            <Card className="text-center p-8 hover:shadow-lg transition-shadow">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
                <Heart className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Autenticidade</h3>
              <p className="text-muted-foreground">
                Cada peça conta uma história. Vestir VerdeRaiz é vestir identidade e propósito.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-accent">
        <div className="container text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Vestir a Amazônia é vestir o futuro
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
            Faça parte deste movimento. Conheça nossa história e compromisso com a COP30.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/sobre">
              <Button size="lg" variant="secondary" className="text-lg px-8 py-6">
                Nossa História
              </Button>
            </Link>
            <Link href="/sustentabilidade">
              <Button size="lg" variant="outline" className="text-lg px-8 py-6 bg-transparent border-primary text-primary hover:bg-primary hover:text-primary-foreground">
                Sustentabilidade
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t bg-muted/20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <img 
                src="/images/logo-new.png" 
                alt="VerdeRaiz" 
                className="h-12 w-auto object-contain mb-4"
              />
              <p className="text-sm text-muted-foreground">
                Vestir a Amazônia é vestir o Futuro
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Navegação</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/colecao"><a className="text-muted-foreground hover:text-foreground transition-colors">Coleção</a></Link></li>
                <li><Link href="/sobre"><a className="text-muted-foreground hover:text-foreground transition-colors">Sobre</a></Link></li>
                <li><Link href="/sustentabilidade"><a className="text-muted-foreground hover:text-foreground transition-colors">Sustentabilidade</a></Link></li>
                <li><Link href="/collabs"><a className="text-muted-foreground hover:text-foreground transition-colors">Collabs</a></Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Suporte</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/contato"><a className="text-muted-foreground hover:text-foreground transition-colors">Contato</a></Link></li>
                <li><a href="#" className="text-muted-foreground hover:text-foreground transition-colors">FAQ</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-foreground transition-colors">Trocas e Devoluções</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Redes Sociais</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="https://www.instagram.com/verderaizpa/" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground transition-colors">Instagram</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-foreground transition-colors">Facebook</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-foreground transition-colors">WhatsApp</a></li>
              </ul>
            </div>
          </div>
          
          <div className="mt-12 pt-8 border-t text-center text-sm text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} VerdeRaiz. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
