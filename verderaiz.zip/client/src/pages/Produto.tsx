import { useState } from "react";
import { useRoute, Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import Header from "@/components/Header";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { ShoppingCart, Leaf, Package, ArrowLeft } from "lucide-react";
import { toast } from "sonner";

export default function Produto() {
  const [, params] = useRoute("/produto/:slug");
  const [, navigate] = useLocation();
  const { isAuthenticated } = useAuth();
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);

  const { data: product, isLoading } = trpc.products.getBySlug.useQuery(
    { slug: params?.slug || "" },
    { enabled: !!params?.slug }
  );

  const { data: category } = trpc.categories.getById.useQuery(
    { id: product?.categoryId || 0 },
    { enabled: !!product?.categoryId }
  );

  const addToCartMutation = trpc.cart.addItem.useMutation({
    onSuccess: () => {
      toast.success("Produto adicionado ao carrinho!");
    },
    onError: (error) => {
      toast.error("Erro ao adicionar ao carrinho: " + error.message);
    },
  });

  const formatPrice = (priceInCents: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(priceInCents / 100);
  };

  const handleAddToCart = () => {
    if (!isAuthenticated) {
      toast.info("Faça login para adicionar produtos ao carrinho");
      window.location.href = getLoginUrl();
      return;
    }

    if (!product) return;

    addToCartMutation.mutate({
      productId: product.id,
      quantity,
    });
  };

  // Parse images array
  const images = product?.images ? JSON.parse(product.images) : [];
  const allImages = [product?.imageUrl, ...images].filter(Boolean);

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="container py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="aspect-square bg-muted animate-pulse rounded-lg" />
            <div className="space-y-4">
              <div className="h-8 bg-muted animate-pulse rounded w-3/4" />
              <div className="h-6 bg-muted animate-pulse rounded w-1/4" />
              <div className="h-24 bg-muted animate-pulse rounded" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="container py-12 text-center">
          <h1 className="text-3xl font-bold mb-4">Produto não encontrado</h1>
          <Link href="/colecao">
            <Button>Voltar para a Coleção</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <div className="container py-8">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
          <Link href="/">
            <a className="hover:text-foreground transition-colors">Início</a>
          </Link>
          <span>/</span>
          <Link href="/colecao">
            <a className="hover:text-foreground transition-colors">Coleção</a>
          </Link>
          {category && (
            <>
              <span>/</span>
              <Link href={`/colecao?categoria=${category.slug}`}>
                <a className="hover:text-foreground transition-colors">{category.name}</a>
              </Link>
            </>
          )}
          <span>/</span>
          <span className="text-foreground">{product.name}</span>
        </div>

        {/* Product Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
          {/* Images Gallery */}
          <div className="space-y-4">
            {/* Main Image */}
            <div className="aspect-square rounded-lg overflow-hidden bg-muted">
              <img
                src={allImages[selectedImage] || "/images/product-1.png"}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Thumbnails */}
            {allImages.length > 1 && (
              <div className="grid grid-cols-4 gap-2">
                {allImages.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(idx)}
                    className={`aspect-square rounded-lg overflow-hidden border-2 transition-colors ${
                      selectedImage === idx ? "border-primary" : "border-transparent"
                    }`}
                  >
                    <img
                      src={img}
                      alt={`${product.name} - ${idx + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              {product.isLimitedEdition && (
                <Badge className="mb-2 bg-secondary">Edição Limitada</Badge>
              )}
              <h1 className="text-4xl font-bold mb-2">{product.name}</h1>
              {category && (
                <p className="text-muted-foreground">Categoria: {category.name}</p>
              )}
            </div>

            <div className="text-3xl font-bold text-primary">
              {formatPrice(product.price)}
            </div>

            {product.description && (
              <div>
                <p className="text-muted-foreground leading-relaxed">
                  {product.description}
                </p>
              </div>
            )}

            <Separator />

            {/* Sustainability Info */}
            {(product.fabric || product.fabricOrigin || product.impactInfo) && (
              <Card className="bg-muted/30">
                <CardContent className="p-6 space-y-3">
                  <div className="flex items-center gap-2 text-primary font-semibold">
                    <Leaf className="h-5 w-5" />
                    <span>Informações de Sustentabilidade</span>
                  </div>
                  {product.fabric && (
                    <div>
                      <span className="font-medium">Tecido:</span> {product.fabric}
                    </div>
                  )}
                  {product.fabricOrigin && (
                    <div>
                      <span className="font-medium">Origem:</span> {product.fabricOrigin}
                    </div>
                  )}
                  {product.impactInfo && (
                    <div>
                      <span className="font-medium">Impacto Ambiental:</span> {product.impactInfo}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Stock Info */}
            <div className="flex items-center gap-2 text-sm">
              <Package className="h-4 w-4" />
              {product.stock > 0 ? (
                <span className="text-muted-foreground">
                  {product.stock > 10 ? "Em estoque" : `Apenas ${product.stock} unidades disponíveis`}
                </span>
              ) : (
                <span className="text-destructive font-medium">Produto esgotado</span>
              )}
            </div>

            {/* Quantity and Add to Cart */}
            {product.stock > 0 && (
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <span className="font-medium">Quantidade:</span>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      disabled={quantity <= 1}
                    >
                      -
                    </Button>
                    <span className="w-12 text-center font-medium">{quantity}</span>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                      disabled={quantity >= product.stock}
                    >
                      +
                    </Button>
                  </div>
                </div>

                <Button
                  size="lg"
                  className="w-full"
                  onClick={handleAddToCart}
                  disabled={addToCartMutation.isPending}
                >
                  <ShoppingCart className="mr-2 h-5 w-5" />
                  {addToCartMutation.isPending ? "Adicionando..." : "Adicionar ao Carrinho"}
                </Button>
              </div>
            )}

            <Button variant="outline" onClick={() => navigate("/colecao")} className="w-full">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Voltar para a Coleção
            </Button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="mt-auto py-12 border-t bg-muted/20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <img 
                src="/images/logo-new.png" 
                alt="VerdeRaiz" 
                className="h-12 w-auto object-contain mb-4"
              />
              <p className="text-sm text-muted-foreground">
                Vestir a Amazônia é vestir o Futuro
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Navegação</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/colecao"><a className="text-muted-foreground hover:text-foreground transition-colors">Coleção</a></Link></li>
                <li><Link href="/sobre"><a className="text-muted-foreground hover:text-foreground transition-colors">Sobre</a></Link></li>
                <li><Link href="/sustentabilidade"><a className="text-muted-foreground hover:text-foreground transition-colors">Sustentabilidade</a></Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Suporte</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/contato"><a className="text-muted-foreground hover:text-foreground transition-colors">Contato</a></Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Redes Sociais</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="https://www.instagram.com/verderaizpa/" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground transition-colors">Instagram</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-foreground transition-colors">WhatsApp</a></li>
              </ul>
            </div>
          </div>
          
          <div className="mt-12 pt-8 border-t text-center text-sm text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} VerdeRaiz. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
