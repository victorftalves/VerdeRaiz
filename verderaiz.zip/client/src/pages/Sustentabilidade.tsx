import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import Header from "@/components/Header";
import { Leaf, Recycle, TreePine, Droplet, Award, Target } from "lucide-react";

export default function Sustentabilidade() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* Hero Section */}
      <section className="relative py-20 bg-primary text-primary-foreground">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <Leaf className="h-16 w-16 mx-auto mb-6" />
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Sustentabilidade em Cada Fio
            </h1>
            <p className="text-xl md:text-2xl opacity-90 leading-relaxed">
              Nosso compromisso com o planeta vai além das palavras. 
              Está em cada escolha, em cada processo, em cada peça.
            </p>
          </div>
        </div>
      </section>

      {/* Materiais Ecológicos */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Materiais Conscientes
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Selecionamos cuidadosamente cada material para minimizar o impacto ambiental
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="p-8 hover:shadow-lg transition-shadow">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
                <TreePine className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-2xl font-bold mb-3">Algodão Orgânico</h3>
              <p className="text-muted-foreground leading-relaxed">
                Cultivado sem pesticidas ou fertilizantes químicos, nosso algodão 
                orgânico preserva a saúde do solo e dos agricultores locais.
              </p>
            </Card>

            <Card className="p-8 hover:shadow-lg transition-shadow">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
                <Recycle className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-2xl font-bold mb-3">Fibras Recicladas</h3>
              <p className="text-muted-foreground leading-relaxed">
                Utilizamos fibras recicladas de garrafas PET e outros materiais, 
                dando nova vida a resíduos e reduzindo o desperdício.
              </p>
            </Card>

            <Card className="p-8 hover:shadow-lg transition-shadow">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
                <Droplet className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-2xl font-bold mb-3">Tingimento Natural</h3>
              <p className="text-muted-foreground leading-relaxed">
                Cores extraídas de plantas e minerais da Amazônia, sem produtos 
                químicos nocivos à água ou ao meio ambiente.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Processo Sustentável */}
      <section className="py-20 bg-muted/30">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold mb-8 text-center">
              Nosso Processo de Produção
            </h2>
            
            <div className="space-y-8">
              <div className="flex gap-6 items-start">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-xl">
                  1
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Seleção de Materiais</h3>
                  <p className="text-muted-foreground">
                    Escolhemos fornecedores certificados que compartilham nossos valores 
                    de sustentabilidade e responsabilidade social.
                  </p>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-xl">
                  2
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Produção Local</h3>
                  <p className="text-muted-foreground">
                    Trabalhamos com malharias e costureiras da região amazônica, 
                    gerando emprego e renda para as comunidades locais.
                  </p>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-xl">
                  3
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Redução de Resíduos</h3>
                  <p className="text-muted-foreground">
                    Otimizamos o corte de tecidos para minimizar desperdícios, e os 
                    retalhos são reutilizados em novos projetos ou doados.
                  </p>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-xl">
                  4
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Embalagem Sustentável</h3>
                  <p className="text-muted-foreground">
                    Usamos embalagens biodegradáveis e recicláveis, evitando plásticos 
                    e materiais que prejudicam o meio ambiente.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* COP30 */}
      <section className="py-20">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full mb-6">
                <Award className="h-5 w-5" />
                <span className="font-semibold">Compromisso COP30</span>
              </div>
              <h2 className="text-4xl font-bold mb-6">
                Rumo à COP30 em Belém
              </h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  A <strong className="text-foreground">COP30</strong>, que acontecerá em Belém do Pará em 2025, 
                  é o maior evento climático do mundo. E a VerdeRaiz está comprometida 
                  em ser parte ativa dessa transformação.
                </p>
                <p>
                  Nosso objetivo é mostrar ao mundo que é possível unir moda, 
                  sustentabilidade e desenvolvimento econômico, valorizando a Amazônia 
                  e suas comunidades.
                </p>
                <p>
                  Estamos trabalhando para reduzir ainda mais nossa pegada de carbono, 
                  investir em projetos de reflorestamento e apoiar iniciativas locais 
                  de preservação ambiental.
                </p>
              </div>
            </div>

            <Card className="p-8 bg-primary text-primary-foreground">
              <h3 className="text-3xl font-bold mb-6">Nossas Metas até 2025</h3>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <Target className="h-6 w-6 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">100% Materiais Sustentáveis</h4>
                    <p className="text-sm opacity-90">
                      Todas as nossas peças produzidas com materiais ecológicos certificados
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Target className="h-6 w-6 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">Neutralidade de Carbono</h4>
                    <p className="text-sm opacity-90">
                      Compensar 100% das emissões através de projetos de reflorestamento
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Target className="h-6 w-6 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">Apoio às Comunidades</h4>
                    <p className="text-sm opacity-90">
                      Gerar 500 empregos diretos e indiretos na região amazônica
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Target className="h-6 w-6 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">Zero Desperdício</h4>
                    <p className="text-sm opacity-90">
                      Implementar sistema de economia circular em toda a produção
                    </p>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-muted/30">
        <div className="container text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Vista o Futuro
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto text-muted-foreground">
            Cada peça VerdeRaiz é um passo em direção a um mundo mais sustentável. 
            Faça parte dessa transformação.
          </p>
          <Link href="/colecao">
            <a className="inline-block">
              <button className="px-8 py-4 bg-primary text-primary-foreground rounded-lg font-semibold hover:opacity-90 transition-opacity">
                Explorar Coleção Sustentável
              </button>
            </a>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t bg-muted/20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <img 
                src="/images/logo-new.png" 
                alt="VerdeRaiz" 
                className="h-12 w-auto object-contain mb-4"
              />
              <p className="text-sm text-muted-foreground">
                Vestir a Amazônia é vestir o Futuro
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Navegação</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/colecao"><a className="text-muted-foreground hover:text-foreground transition-colors">Coleção</a></Link></li>
                <li><Link href="/sobre"><a className="text-muted-foreground hover:text-foreground transition-colors">Sobre</a></Link></li>
                <li><Link href="/sustentabilidade"><a className="text-muted-foreground hover:text-foreground transition-colors">Sustentabilidade</a></Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Suporte</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/contato"><a className="text-muted-foreground hover:text-foreground transition-colors">Contato</a></Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Redes Sociais</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="https://www.instagram.com/verderaizpa/" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground transition-colors">Instagram</a></li>
              </ul>
            </div>
          </div>
          
          <div className="mt-12 pt-8 border-t text-center text-sm text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} VerdeRaiz. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
