# VerdeRaiz - TODO List

## Configuração Inicial
- [x] Copiar ativos visuais (logo e imagens de produtos) para o projeto
- [x] Configurar schema do banco de dados (produtos, categorias, carrinho, pedidos)

## Design System e Tema
- [x] Implementar paleta de cores VerdeRaiz (verde musgo, bege areia, marrom argila, branco natural)
- [x] Configurar tipografia (Poppins + fonte orgânica)
- [x] Criar componentes base reutilizáveis

## Páginas Principais
- [x] Página inicial (Home) com hero section e destaques de categorias
- [x] Página de catálogo de produtos (Coleção) com filtros
- [x] Página de detalhes do produto com galeria de imagens
- [x] Página de carrinho de compras
- [x] Página de checkout

## Páginas Institucionais
- [x] Página Sobre (manifesto da marca)
- [x] Página Sustentabilidade (materiais ecológicos, parcerias, COP30)
- [x] Página Collabs (parcerias e selo VerdeRaiz)
- [x] Página Contato (formulário e WhatsApp)

## Funcionalidades E-commerce
- [x] Sistema de carrinho de compras
- [x] Processo de checkout
- [ ] Integração de pagamento
- [ ] Gerenciamento de pedidos

## Painel Administrativo
- [x] Dashboard de administração (dados populados no banco)
- [x] CRUD de produtos (via Database UI)
- [x] Gerenciamento de categorias (via Database UI)
- [x] Visualização e gestão de pedidos (via Database UI)

## Finalização
- [x] Testes de responsividade
- [x] Otimização de performance
- [x] Checkpoint final

## Melhorias Estéticas (Solicitadas)
- [x] Substituir logo antiga pela nova versão sem fundo
- [x] Remover fundos pretos/escuros e aplicar cores mais atrativas
- [x] Ajustar paleta de cores para tons terrosos e naturais
- [x] Atualizar valor do frete para R$ 30,00 (Belém e região metropolitana)
- [x] Adicionar link do Instagram oficial (@verderaizpa) no footer
- [x] Adicionar link do Instagram na página de contato

## Correções Urgentes
- [ ] Identificar e corrigir todos os fundos pretos/escuros remanescentes
- [ ] Aplicar fundo bege/terroso (#F5F2EC) em todas as seções
- [ ] Implementar formulário de contato detalhado para pedidos personalizados
- [ ] Testar todas as páginas para garantir consistência visual
